package bangun_datar;


public interface Shape {
    double hitungLuas();
    double hitungKeliling();
}

