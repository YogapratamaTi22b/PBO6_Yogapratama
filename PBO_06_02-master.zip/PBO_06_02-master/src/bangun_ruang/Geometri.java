package bangun_ruang;

public interface Geometri {
    double hitungVolume();
    double hitungLuasPermukaan();
}
